package com.healthlens;

import com.healthlens.concurrency.ActivityCenterController;
import com.healthlens.concurrency.BackgroundServices;
import com.healthlens.concurrency.BreathingSession;
import com.healthlens.concurrency.HealthSnapshot;
import com.healthlens.concurrency.MergedReading;
import com.healthlens.concurrency.Notification;
import com.healthlens.concurrency.SourceReading;
import com.healthlens.concurrency.SyncService;
import com.healthlens.model.HealthData;
import com.healthlens.model.ScoreCalculator;
import com.healthlens.model.ScoreResult;
import com.healthlens.json.JsonHealthService;

import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.PauseTransition;
import javafx.animation.ScaleTransition;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.Slider;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Circle;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.shape.SVGPath;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.prefs.Preferences;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicLong;

/**
 * CONTROLLER for HealthLens.fxml.
 *
 * This class's only job is to mediate between the VIEW (the FXML controls
 * below) and the MODEL (com.healthlens.model.HealthData / ScoreCalculator /
 * ScoreResult). It reads input controls, asks the Model to do the actual
 * health-scoring work, and pushes the Model's results back onto the UI.
 * It intentionally contains NO scoring formulas or health-summary wording —
 * that all lives in ScoreCalculator, which has no idea JavaFX exists.
 *
 * Field names below are bound to fx:id values in the FXML via @FXML.
 * If you rename an fx:id in Scene Builder, rename the matching field here too.
 */
public class HealthLensController {

    // --- Background layer ---
    @FXML private StackPane rootPane;
    @FXML private ImageView backgroundImageView;
    @FXML private StackPane scrimPane;

    // --- Top bar ---
    @FXML private Button themeToggleButton;
    @FXML private Button settingsButton;
    @FXML private Button chatButton;
    @FXML private Button activityCenterButton;
    private Label activityBadgeLabel;
    @FXML private Label subtitleLabel;
    @FXML private Label reminderBanner;
    @FXML private StackPane profileAvatarStack;
    @FXML private Circle profileCircleBg;
    @FXML private Label profileInitialsLabel;
    @FXML private ImageView profileImageView;

    // --- Inputs ---
    @FXML private Slider sleepSlider;
    @FXML private Label sleepValueLabel;

    @FXML private Slider waterSlider;
    @FXML private Label waterValueLabel;

    @FXML private Slider exerciseSlider;
    @FXML private Label exerciseValueLabel;

    @FXML private Slider stressSlider;
    @FXML private Label stressValueLabel;
    @FXML private Button breathingButton;
    @FXML private Label breathingStatusLabel;

    @FXML private ChoiceBox<String> moodChoiceBox;

    @FXML private Button updateButton;
    @FXML private Button resetButton;
    @FXML private Button syncButton;
    @FXML private Button jsonButton;

    // --- Outputs: progress bars + goal labels ---
    @FXML private ProgressBar sleepBar;
    @FXML private ProgressBar waterBar;
    @FXML private ProgressBar exerciseBar;
    @FXML private ProgressBar stressBar;

    @FXML private Label sleepGoalLabel;
    @FXML private Label waterGoalLabel;
    @FXML private Label exerciseGoalLabel;
    @FXML private Label stressGoalLabel;

    // --- Outputs: chart ---
    @FXML private BarChart<String, Number> healthChart;
    @FXML private CategoryAxis xAxis;
    @FXML private NumberAxis yAxis;

    // --- Outputs: summary ---
    @FXML private Label overallScoreLabel;
    @FXML private Label summaryLabel;
    @FXML private HBox batterySegments;
    @FXML private Label batteryPercentLabel;

    private final List<Region> batterySegmentNodes = new ArrayList<>();

    // Recommendation engine: calculations run off the JavaFX Application Thread.
    private final ExecutorService recommendationExecutor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "healthlens-recommendation-worker");
        t.setDaemon(true);
        return t;
    });
    private final AtomicLong recommendationVersion = new AtomicLong();
    private Stage recommendationsStage;
    private VBox recommendationsContent;
    private Label recommendationStatusLabel;

    /** THE MODEL. Everything about "what the data means" is delegated to this + ScoreCalculator. */
    private final HealthData healthData = new HealthData();

    private boolean darkMode = false;
    private XYChart.Series<String, Number> chartSeries;

    // Where saved settings/preferences live (per OS user, no file management needed)
    private final Preferences prefs = Preferences.userNodeForPackage(HealthLensController.class);

    @FXML
    public void initialize() {
        loadPreferences();
        setupBackgroundImage();
        setupMoodChoices();
        setupLiveValueLabels();
        setupChart();
        setupKeyboardShortcut();
        updateGoalLabels();
        applyThemeWhenSceneReady();
        setupProfileAvatar();
        setupActivityCenterIcon();
        setupBatteryIndicator();
        Tooltip.install(profileAvatarStack, new Tooltip("Your profile — click to change picture, email, or background"));
        startBackgroundServices();

        // Show an initial snapshot on load
        handleUpdate();
    }

    /** Set once a user logs in/signs up; used to key per-user profile preferences. */
    private String currentUsername;
    private String currentEmail;

    /**
     * Called by GuideController right after loading this screen, if the
     * user came in through Login/Signup -> Guide -> HealthLens. Demonstrates
     * passing data between scenes: the username and email typed earlier end
     * up here, and are used to load this user's saved profile picture and
     * background image (if any were set previously).
     */
    public void initSession(String userName, String userEmail) {
        this.currentUsername = userName;
        this.currentEmail = userEmail;
        if (userName != null && !userName.isBlank()) {
            subtitleLabel.setText("Welcome back, " + userName + "! Your daily health habits, visualized.");
        }
        setupProfileAvatar();
        applyCustomBackgroundIfAny();
    }

    // ===================== BACKGROUND IMAGE =====================

    /**
     * Loads /com/healthlens/background.jpg from resources and stretches it to
     * fill the window. If the file is missing, falls back to a plain gradient
     * (set in styles.css on #rootPane) so the app never crashes because an
     * image wasn't supplied yet.
     *
     * TO CHANGE THE BACKGROUND IMAGE:
     * Drop your image file into src/main/resources/com/healthlens/ and rename
     * it to "background.jpg" (or edit the path below).
     */
    private void setupBackgroundImage() {
        try (InputStream is = getClass().getResourceAsStream("background.jpg")) {
            if (is != null) {
                Image image = new Image(is);
                backgroundImageView.setImage(image);
            } else {
                System.out.println("[HealthLens] No background.jpg found in resources — "
                        + "using fallback background color. See styles.css (#root-pane).");
            }
        } catch (Exception e) {
            System.out.println("[HealthLens] Could not load background image: " + e.getMessage());
        }

        // Keep the image filling the entire window at all times, including on resize.
        backgroundImageView.fitWidthProperty().bind(rootPane.widthProperty());
        backgroundImageView.fitHeightProperty().bind(rootPane.heightProperty());

        // Keep the readability scrim the same size as the window too.
        scrimPane.prefWidthProperty().bind(rootPane.widthProperty());
        scrimPane.prefHeightProperty().bind(rootPane.heightProperty());
    }

    // ===================== SETUP =====================

    private void setupMoodChoices() {
        moodChoiceBox.setItems(FXCollections.observableArrayList(
                "Great", "Good", "Okay", "Low", "Stressed"
        ));
        moodChoiceBox.setValue(healthData.getMood());
    }

    private void setupLiveValueLabels() {
        sleepSlider.valueProperty().addListener((obs, oldV, newV) ->
                sleepValueLabel.setText(String.format(Locale.US, "%.1f h", newV.doubleValue())));

        waterSlider.valueProperty().addListener((obs, oldV, newV) ->
                waterValueLabel.setText(String.format(Locale.US, "%d", Math.round(newV.doubleValue()))));

        exerciseSlider.valueProperty().addListener((obs, oldV, newV) ->
                exerciseValueLabel.setText(String.format(Locale.US, "%d min", Math.round(newV.doubleValue()))));

        stressSlider.valueProperty().addListener((obs, oldV, newV) -> {
            stressValueLabel.setText(String.format(Locale.US, "%d", Math.round(newV.doubleValue())));
            requestRecommendationRefresh();
        });

        sleepSlider.valueProperty().addListener((obs, oldV, newV) -> requestRecommendationRefresh());
        waterSlider.valueProperty().addListener((obs, oldV, newV) -> requestRecommendationRefresh());
        exerciseSlider.valueProperty().addListener((obs, oldV, newV) -> requestRecommendationRefresh());
        moodChoiceBox.valueProperty().addListener((obs, oldV, newV) -> requestRecommendationRefresh());
    }

    private void setupChart() {
        xAxis.setCategories(FXCollections.observableArrayList("Sleep", "Water", "Exercise", "Stress ctrl"));
        chartSeries = new XYChart.Series<>();
        chartSeries.getData().add(new XYChart.Data<>("Sleep", 0));
        chartSeries.getData().add(new XYChart.Data<>("Water", 0));
        chartSeries.getData().add(new XYChart.Data<>("Exercise", 0));
        chartSeries.getData().add(new XYChart.Data<>("Stress ctrl", 0));
        healthChart.getData().add(chartSeries);
    }

    /** Enter key anywhere in the window triggers "Update Dashboard". */
    private void setupKeyboardShortcut() {
        rootPane.sceneProperty().addListener((obs, oldScene, newScene) -> {
            if (newScene != null) {
                newScene.setOnKeyPressed(event -> {
                    if (event.getCode() == KeyCode.ENTER) {
                        handleUpdate();
                    }
                });
            }
        });
    }

    // ===================== BACKGROUND SERVICES =====================

    /**
     * Every thread, pool and queue in HealthLens lives behind this one
     * object. The dashboard starts it once and shuts it down once. Nothing
     * else in the UI layer ever creates a Thread directly, which is the
     * whole reason the app can be closed cleanly instead of leaving worker
     * threads running and the JVM refusing to exit.
     */
    private final BackgroundServices services = new BackgroundServices();

    private void startBackgroundServices() {
        services.start();

        // Reminders are produced on one background thread and delivered on
        // another. This callback arrives on the notifier thread, so the
        // banner update has to hop back onto the JavaFX thread first.
        services.getNotificationCenter().addListener(notification ->
                Platform.runLater(() -> showReminderBanner(notification)));

        // One place to stop everything when the window closes.
        rootPane.sceneProperty().addListener((obs, oldScene, newScene) -> {
            if (newScene != null) {
                newScene.windowProperty().addListener((o2, oldWindow, newWindow) -> {
                    if (newWindow != null) {
                        newWindow.setOnCloseRequest(e -> { services.shutdown(); recommendationExecutor.shutdownNow(); });
                    }
                });
            }
        });
    }

    private void showReminderBanner(Notification notification) {
        reminderBanner.setText(notification.getText());
        reminderBanner.setVisible(true);
        reminderBanner.setManaged(true);
        updateNotificationBadge();

        PauseTransition hide = new PauseTransition(Duration.seconds(8));
        hide.setOnFinished(e -> {
            reminderBanner.setVisible(false);
            reminderBanner.setManaged(false);
        });
        hide.play();
    }

    /** Builds a real vector activity/pulse icon instead of using a Unicode glyph. */
    private void setupActivityCenterIcon() {
        SVGPath pulse = new SVGPath();
        pulse.setContent("M2 12 H6 L9 5 L13 19 L16 12 H22");
        pulse.setFill(Color.TRANSPARENT);
        pulse.setStroke(Color.web("#0ea5a1"));
        pulse.setStrokeWidth(2.2);
        pulse.setStrokeLineCap(StrokeLineCap.ROUND);
        pulse.setStrokeLineJoin(javafx.scene.shape.StrokeLineJoin.ROUND);

        StackPane icon = new StackPane();
        icon.setPrefSize(22, 22);
        icon.setMinSize(22, 22);
        icon.setMaxSize(22, 22);
        icon.getChildren().add(pulse);

        activityBadgeLabel = new Label();
        activityBadgeLabel.setStyle(
                "-fx-background-color: #ef4444;" +
                "-fx-background-radius: 10;" +
                "-fx-text-fill: white;" +
                "-fx-font-size: 8px;" +
                "-fx-font-weight: bold;" +
                "-fx-alignment: center;" +
                "-fx-padding: 0;" +
                "-fx-min-width: 14px; -fx-min-height: 14px;" +
                "-fx-max-width: 14px; -fx-max-height: 14px;");
        StackPane.setAlignment(activityBadgeLabel, javafx.geometry.Pos.TOP_RIGHT);
        StackPane.setMargin(activityBadgeLabel, new Insets(-4, -6, 0, 0));
        icon.getChildren().add(activityBadgeLabel);

        activityCenterButton.setText("");
        activityCenterButton.setGraphic(icon);
        activityCenterButton.setContentDisplay(javafx.scene.control.ContentDisplay.GRAPHIC_ONLY);
    }

    /** Updates the unread badge without moving or replacing the icon itself. */
    private void updateNotificationBadge() {
        int unread = services.getNotificationCenter().getUnreadCount();
        if (activityBadgeLabel == null) {
            return;
        }
        activityBadgeLabel.setText(unread > 99 ? "99+" : String.valueOf(unread));
        activityBadgeLabel.setVisible(unread > 0);
        activityBadgeLabel.setManaged(unread > 0);
    }

    // ===================== GUIDED BREATHING =====================

    /**
     * Starts or stops the breathing exercise. The session itself lives in
     * BreathingSession; this method's only job is to translate its
     * callbacks back onto the JavaFX thread and keep the button label in
     * step with reality.
     */
    @FXML
    private void handleToggleBreathing() {
        BreathingSession session = services.getBreathingSession();

        if (session.isRunning()) {
            session.stop();   // cooperative: asks, never forces
            return;
        }

        breathingButton.setText("\u23F9 Stop");

        session.start(3, new BreathingSession.Listener() {
            @Override
            public void onPhase(String phase, int phaseIndex, int totalPhases) {
                Platform.runLater(() ->
                        breathingStatusLabel.setText(phase + "  (" + phaseIndex + "/" + totalPhases + ")"));
            }

            @Override
            public void onFinished(boolean completedFully) {
                Platform.runLater(() -> {
                    breathingButton.setText("\uD83E\uDDD8 Guided Breathing");
                    if (completedFully) {
                        breathingStatusLabel.setText("Done — nicely paced.");
                        // A finished session earns a real reward: stress
                        // drops a point on the actual dashboard.
                        stressSlider.setValue(Math.max(stressSlider.getMin(), stressSlider.getValue() - 1));
                        handleUpdate();
                    } else {
                        breathingStatusLabel.setText("Stopped early — that's okay too.");
                    }
                });
            }
        });
    }

    // ===================== SYNC ALL SOURCES =====================

    /**
     * Fetches every connected source at the same time. All of the executor
     * work is inside SyncService; what stays here is the UI half — disable
     * the button, show progress as each source reports, apply the merged
     * result when everything is in.
     *
     * Note what is NOT here: no future.get(), no join(), no sleep(). A
     * button handler runs on the JavaFX thread, and blocking it for even a
     * second would visibly freeze the window.
     */
    @FXML
    private void handleSyncWithDevice() {
        SyncService sync = services.getSyncService();

        boolean started = sync.syncAll(new SyncService.Listener() {
            @Override
            public void onSyncStarted(java.util.List<String> sourceNames) {
                Platform.runLater(() -> {
                    syncButton.setDisable(true);
                    syncButton.setText("Syncing 0/" + sourceNames.size() + "…");
                });
            }

            @Override
            public void onSourceFinished(SourceReading reading) {
                Platform.runLater(() -> {
                    int done = ++sourcesDone;
                    syncButton.setText("Syncing " + done + "/" + sync.getSourceNames().size() + "…");
                });
            }

            @Override
            public void onSyncFinished(MergedReading merged, java.util.List<SourceReading> readings) {
                Platform.runLater(() -> {
                    applyMergedReading(merged);
                    sourcesDone = 0;
                    syncButton.setDisable(false);
                    syncButton.setText("\uD83D\uDD04 Sync All Sources");
                });
            }
        });

        if (!started) {
            syncButton.setText("Already syncing…");
        }
    }

    /** Counter for the progress label. Only ever touched on the FX thread. */
    private int sourcesDone = 0;

    /** Applies whatever came back, leaving anything that failed untouched. */
    private void applyMergedReading(MergedReading merged) {
        if (merged.getSleepHours() != null) {
            sleepSlider.setValue(clamp(merged.getSleepHours(), sleepSlider.getMin(), sleepSlider.getMax()));
        }
        if (merged.getWaterGlasses() != null) {
            waterSlider.setValue(clamp(merged.getWaterGlasses(), waterSlider.getMin(), waterSlider.getMax()));
        }
        if (merged.getExerciseMinutes() != null) {
            exerciseSlider.setValue(clamp(merged.getExerciseMinutes(), exerciseSlider.getMin(), exerciseSlider.getMax()));
        }
        if (merged.getStressLevel() != null) {
            stressSlider.setValue(clamp(merged.getStressLevel(), stressSlider.getMin(), stressSlider.getMax()));
        }
        handleUpdate();
    }

    // ===================== ACTIVITY CENTRE =====================

    @FXML
    private void handleOpenActivityCenter() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/healthlens/concurrency/ActivityCenter.fxml"));
            Parent centreRoot = loader.load();

            ActivityCenterController centreController = loader.getController();
            centreController.init(services);

            Scene centreScene = new Scene(centreRoot, 560, 620);
            centreScene.getStylesheets().add(
                    getClass().getResource(darkMode ? "styles-dark.css" : "styles.css").toExternalForm());

            Stage centreStage = new Stage();
            centreStage.setTitle("HealthLens — Activity Centre");
            centreStage.setScene(centreScene);
            centreStage.setOnCloseRequest(e -> centreController.dispose());
            centreStage.show();

            // Opening the centre counts as reading your reminders.
            services.getNotificationCenter().markAllRead();
            updateNotificationBadge();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateGoalLabels() {
        sleepGoalLabel.setText(String.format(Locale.US, "Sleep goal (%.0fh)", healthData.getSleepGoalHours()));
        waterGoalLabel.setText(String.format(Locale.US, "Water goal (%.0f glasses)", healthData.getWaterGoalGlasses()));
        exerciseGoalLabel.setText(String.format(Locale.US, "Exercise goal (%.0f min)", healthData.getExerciseGoalMinutes()));
        stressGoalLabel.setText(String.format(Locale.US, "Stress control (comfortable ≤ %.0f)", healthData.getStressComfortMax()));
    }

    // ===================== THEME (LIGHT / DARK) =====================

    private void applyThemeWhenSceneReady() {
        rootPane.sceneProperty().addListener((obs, oldScene, newScene) -> {
            if (newScene != null) {
                applyTheme(newScene);
            }
        });
    }

    @FXML
    private void handleToggleTheme() {
        darkMode = !darkMode;
        Scene scene = rootPane.getScene();
        if (scene != null) {
            applyTheme(scene);
        }
        prefs.putBoolean("darkMode", darkMode);
    }

    private void applyTheme(Scene scene) {
        String stylesheet = darkMode ? "styles-dark.css" : "styles.css";
        scene.getStylesheets().clear();
        scene.getStylesheets().add(getClass().getResource(stylesheet).toExternalForm());
        themeToggleButton.setText(darkMode ? "☀" : "◐");
    }

    // ===================== PROFILE (AVATAR / EMAIL / BACKGROUND) =====================

    private void setupProfileAvatar() {
        Circle clip = new Circle(17, 17, 17);
        profileImageView.setClip(clip);
        profileCircleBg.setFill(Color.web("#0ea5a1"));

        String initial = (currentUsername != null && !currentUsername.isBlank())
                ? currentUsername.substring(0, 1).toUpperCase() : "?";
        profileInitialsLabel.setText(initial);

        String savedPicturePath = currentUsername == null ? null
                : prefs.get("profile." + currentUsername + ".picturePath", null);
        if (savedPicturePath != null && new File(savedPicturePath).exists()) {
            profileImageView.setImage(new Image(new File(savedPicturePath).toURI().toString()));
            profileImageView.setVisible(true);
            profileInitialsLabel.setVisible(false);
        } else {
            profileImageView.setVisible(false);
            profileInitialsLabel.setVisible(true);
        }
    }

    private void applyCustomBackgroundIfAny() {
        if (currentUsername == null) {
            return;
        }
        String savedBackgroundPath = prefs.get("profile." + currentUsername + ".backgroundPath", null);
        if (savedBackgroundPath != null && new File(savedBackgroundPath).exists()) {
            backgroundImageView.setImage(new Image(new File(savedBackgroundPath).toURI().toString()));
        }
    }

    @FXML
    private void handleOpenProfile() {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Your Profile");
        dialog.setHeaderText(currentUsername == null ? "Profile" : "Signed in as " + currentUsername);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
        dialog.getDialogPane().getStylesheets().add(
                getClass().getResource(darkMode ? "styles-dark.css" : "styles.css").toExternalForm());

        GridPane grid = new GridPane();
        grid.setHgap(12);
        grid.setVgap(14);
        grid.setPadding(new Insets(16));

        // --- profile picture ---
        ImageView previewView = new ImageView();
        previewView.setFitWidth(60);
        previewView.setFitHeight(60);
        previewView.setClip(new Circle(30, 30, 30));
        if (profileImageView.getImage() != null) {
            previewView.setImage(profileImageView.getImage());
        }
        Button changePictureButton = new Button("Change Picture...");
        changePictureButton.getStyleClass().add("reset-button");
        changePictureButton.setOnAction(e -> {
            File file = chooseImageFile("Choose a profile picture");
            if (file != null && currentUsername != null) {
                prefs.put("profile." + currentUsername + ".picturePath", file.getAbsolutePath());
                previewView.setImage(new Image(file.toURI().toString()));
                setupProfileAvatar();
            }
        });
        grid.add(new Label("Profile picture:"), 0, 0);
        grid.add(new HBox(10, previewView, changePictureButton), 1, 0);

        // --- email ---
        TextField emailField = new TextField(currentEmail == null ? "" : currentEmail);
        emailField.setPrefWidth(200);
        Button saveEmailButton = new Button("Save");
        saveEmailButton.getStyleClass().add("reset-button");
        saveEmailButton.setOnAction(e -> {
            if (currentUsername != null) {
                currentEmail = emailField.getText();
                prefs.put("user." + currentUsername + ".email", currentEmail);
                Alert confirm = new Alert(Alert.AlertType.INFORMATION);
                confirm.setTitle("Email updated");
                confirm.setHeaderText(null);
                confirm.setContentText("Your email has been updated.");
                confirm.showAndWait();
            }
        });
        grid.add(new Label("Email:"), 0, 1);
        grid.add(new HBox(10, emailField, saveEmailButton), 1, 1);

        // --- background image ---
        Button changeBackgroundButton = new Button("Change Background Image...");
        changeBackgroundButton.getStyleClass().add("reset-button");
        changeBackgroundButton.setOnAction(e -> {
            File file = chooseImageFile("Choose a background image");
            if (file != null) {
                backgroundImageView.setImage(new Image(file.toURI().toString()));
                if (currentUsername != null) {
                    prefs.put("profile." + currentUsername + ".backgroundPath", file.getAbsolutePath());
                }
            }
        });
        grid.add(new Label("Background image:"), 0, 2);
        grid.add(changeBackgroundButton, 1, 2);

        dialog.getDialogPane().setContent(grid);
        dialog.showAndWait();
    }

    private File chooseImageFile(String title) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle(title);
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg", "*.gif"));
        Stage stage = (Stage) profileAvatarStack.getScene().getWindow();
        return fileChooser.showOpenDialog(stage);
    }

    // ===================== SETTINGS DIALOG (CUSTOM GOALS) =====================

    @FXML
    private void handleOpenSettings() {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Customize Your Goals");
        dialog.setHeaderText("Set the daily targets HealthLens should track you against.");

        ButtonType saveButtonType = new ButtonType("Save", ButtonType.OK.getButtonData());
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(12);
        grid.setVgap(12);
        grid.setPadding(new Insets(16));

        Spinner<Double> sleepGoalSpinner = new Spinner<>(
                new SpinnerValueFactory.DoubleSpinnerValueFactory(1, 12, healthData.getSleepGoalHours(), 0.5));
        Spinner<Double> waterGoalSpinner = new Spinner<>(
                new SpinnerValueFactory.DoubleSpinnerValueFactory(1, 15, healthData.getWaterGoalGlasses(), 1));
        Spinner<Double> exerciseGoalSpinner = new Spinner<>(
                new SpinnerValueFactory.DoubleSpinnerValueFactory(5, 120, healthData.getExerciseGoalMinutes(), 5));
        Spinner<Double> stressMaxSpinner = new Spinner<>(
                new SpinnerValueFactory.DoubleSpinnerValueFactory(1, 10, healthData.getStressComfortMax(), 1));

        for (Spinner<Double> s : new Spinner[]{sleepGoalSpinner, waterGoalSpinner, exerciseGoalSpinner, stressMaxSpinner}) {
            s.setEditable(true);
            s.setPrefWidth(100);
        }

        grid.add(new Label("Sleep goal (hours):"), 0, 0);
        grid.add(sleepGoalSpinner, 1, 0);
        grid.add(new Label("Water goal (glasses):"), 0, 1);
        grid.add(waterGoalSpinner, 1, 1);
        grid.add(new Label("Exercise goal (minutes):"), 0, 2);
        grid.add(exerciseGoalSpinner, 1, 2);
        grid.add(new Label("Stress comfortable at or below:"), 0, 3);
        grid.add(stressMaxSpinner, 1, 3);

        dialog.getDialogPane().setContent(grid);

        // Match the app's current theme so the popup doesn't feel out of place
        dialog.getDialogPane().getStylesheets().add(
                getClass().getResource(darkMode ? "styles-dark.css" : "styles.css").toExternalForm());

        dialog.showAndWait().ifPresent(result -> {
            if (result == saveButtonType) {
                healthData.setSleepGoalHours(sleepGoalSpinner.getValue());
                healthData.setWaterGoalGlasses(waterGoalSpinner.getValue());
                healthData.setExerciseGoalMinutes(exerciseGoalSpinner.getValue());
                healthData.setStressComfortMax(stressMaxSpinner.getValue());

                savePreferences();
                updateGoalLabels();
                handleUpdate();
            }
        });
    }

    // ===================== CHAT ASSISTANT =====================

    /**
     * Opens a small chat window where the user can type sentences like
     * "I slept 7 hours and drank 4 glasses of water, feeling stressed".
     * ChatParser (rule-based, no ML model) extracts whatever it can. The
     * Controller applies matched values to the sliders/mood (the VIEW),
     * then calls handleUpdate(), which is the normal path that copies View
     * values into the Model and re-scores.
     */
    @FXML
    private void handleOpenChat() {
        Stage chatStage = new Stage();
        chatStage.setTitle("HealthLens Assistant");
        chatStage.initModality(Modality.NONE);
        chatStage.initOwner(rootPane.getScene() != null ? rootPane.getScene().getWindow() : null);

        ListView<String> chatLog = new ListView<>();
        chatLog.getStyleClass().add("chat-log");
        chatLog.setPrefHeight(320);
        chatLog.setFocusTraversable(false);
        chatLog.getItems().add("Bot: Tell me about your day — e.g. \"I slept 7 hours, drank "
                + "5 glasses of water, exercised 20 minutes, feeling stressed.\"");

        TextField input = new TextField();
        input.setPromptText("Type a message and press Enter...");
        HBox.setHgrow(input, Priority.ALWAYS);

        Button sendButton = new Button("Send");
        sendButton.getStyleClass().add("primary-button");

        Runnable sendMessage = () -> {
            String text = input.getText();
            if (text == null || text.isBlank()) {
                return;
            }
            chatLog.getItems().add("You: " + text);
            String reply = processChatMessage(text);
            chatLog.getItems().add("Bot: " + reply);
            chatLog.scrollTo(chatLog.getItems().size() - 1);
            input.clear();
        };

        sendButton.setOnAction(e -> sendMessage.run());
        input.setOnAction(e -> sendMessage.run());

        HBox inputRow = new HBox(8, input, sendButton);
        VBox root = new VBox(10, chatLog, inputRow);
        root.setPadding(new Insets(16));
        root.getStyleClass().add("chat-window");

        Scene chatScene = new Scene(root, 420, 440);
        chatScene.getStylesheets().add(
                getClass().getResource(darkMode ? "styles-dark.css" : "styles.css").toExternalForm());

        chatStage.setScene(chatScene);
        chatStage.show();
    }

    /**
     * Runs the typed message through ChatParser, applies any values it
     * found to the real sliders/mood picker, refreshes the dashboard, and
     * returns a human-readable reply describing what was understood.
     */
    private String processChatMessage(String message) {
        ChatParser.ChatUpdate update = ChatParser.parse(message);

        if (update.isEmpty()) {
            return "I couldn't pick anything out of that — try mentioning hours of sleep, "
                    + "glasses of water, minutes of exercise, a stress level, or how you're feeling.";
        }

        List<String> understood = new ArrayList<>();

        if (update.sleepHours != null) {
            sleepSlider.setValue(clamp(update.sleepHours, sleepSlider.getMin(), sleepSlider.getMax()));
            understood.add(String.format(Locale.US, "sleep: %.1fh", update.sleepHours));
        }
        if (update.waterGlasses != null) {
            waterSlider.setValue(clamp(update.waterGlasses, waterSlider.getMin(), waterSlider.getMax()));
            understood.add(String.format(Locale.US, "water: %.0f glasses", update.waterGlasses));
        }
        if (update.exerciseMinutes != null) {
            exerciseSlider.setValue(clamp(update.exerciseMinutes, exerciseSlider.getMin(), exerciseSlider.getMax()));
            understood.add(String.format(Locale.US, "exercise: %.0f min", update.exerciseMinutes));
        }
        if (update.stressLevel != null) {
            stressSlider.setValue(clamp(update.stressLevel, stressSlider.getMin(), stressSlider.getMax()));
            understood.add(String.format(Locale.US, "stress: %.0f/10", update.stressLevel));
        }
        if (update.mood != null) {
            moodChoiceBox.setValue(update.mood);
            understood.add("mood: " + update.mood);
        }

        handleUpdate();

        return "Got it — updated " + String.join(", ", understood) + ". Dashboard refreshed!";
    }

    private double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }

    // ===================== UPDATE (VIEW -> MODEL -> VIEW) =====================

    /**
     * The core Controller flow:
     *   1) Read the VIEW (sliders/mood) into the MODEL (healthData)
     *   2) Ask the MODEL (via ScoreCalculator) to compute a ScoreResult
     *   3) Push that ScoreResult back onto the VIEW (bars, chart, summary)
     * No scoring math or health advice text lives in this method — see
     * ScoreCalculator for that.
     */
    @FXML
    private void handleUpdate() {
        // 1) View -> Model
        healthData.setSleepHours(sleepSlider.getValue());
        healthData.setWaterGlasses(waterSlider.getValue());
        healthData.setExerciseMinutes(exerciseSlider.getValue());
        healthData.setStressLevel(stressSlider.getValue());
        healthData.setMood(moodChoiceBox.getValue());

        // 2) Model does the work
        ScoreResult result = ScoreCalculator.calculate(healthData);

        // 3) Model -> View
        animateBar(sleepBar, result.getSleepScore());
        animateBar(waterBar, result.getWaterScore());
        animateBar(exerciseBar, result.getExerciseScore());
        animateBar(stressBar, result.getStressScore());

        chartSeries.getData().get(0).setYValue(result.getSleepScore() * 100);
        chartSeries.getData().get(1).setYValue(result.getWaterScore() * 100);
        chartSeries.getData().get(2).setYValue(result.getExerciseScore() * 100);
        chartSeries.getData().get(3).setYValue(result.getStressScore() * 100);

        renderSummary(result);
        savePreferences();

        // 4) Hand the background reminder thread an immutable copy of where
        //    the user now stands. It must never read the sliders itself.
        services.getReminderService().publishSnapshot(new HealthSnapshot(
                healthData.getSleepHours(),
                healthData.getWaterGlasses(),
                healthData.getExerciseMinutes(),
                healthData.getStressLevel(),
                healthData.getSleepGoalHours(),
                healthData.getWaterGoalGlasses(),
                healthData.getExerciseGoalMinutes(),
                healthData.getStressComfortMax()));
    }

    /**
     * Opens a separate smart recommendation dashboard. The worker thread calculates
     * recommendations from an immutable snapshot, while Platform.runLater updates
     * the JavaFX scene. This keeps the main GUI responsive and demonstrates
     * producer/consumer-style concurrency.
     */
    @FXML
    private void handleOpenRecommendations() {
        if (recommendationsStage != null && recommendationsStage.isShowing()) {
            recommendationsStage.toFront();
            requestRecommendationRefresh();
            return;
        }

        recommendationsContent = new VBox(14);
        recommendationsContent.setPadding(new Insets(20));
        recommendationsContent.getStyleClass().add("recommendations-content");

        Label heading = new Label("Actions should be taken for better health");
        heading.getStyleClass().add("recommendations-heading");
        Label intro = new Label("Live recommendations update in the background as your dashboard values change.");
        intro.setWrapText(true);
        intro.getStyleClass().add("recommendations-intro");
        recommendationStatusLabel = new Label("Preparing your recommendations...");
        recommendationStatusLabel.getStyleClass().add("recommendation-status");
        recommendationsContent.getChildren().addAll(heading, intro, recommendationStatusLabel);

        recommendationsStage = new Stage();
        recommendationsStage.setTitle("HealthLens • Smart Recommendations");
        recommendationsStage.initModality(Modality.NONE);
        recommendationsStage.setScene(new Scene(recommendationsContent, 720, 650));
        applyStylesToScene(recommendationsStage.getScene());
        recommendationsStage.setOnCloseRequest(event -> {
            recommendationsStage = null;
            recommendationsContent = null;
            recommendationStatusLabel = null;
        });
        recommendationsStage.show();
        requestRecommendationRefresh();
    }

    private void requestRecommendationRefresh() {
        if (recommendationsContent == null || recommendationsStage == null || !recommendationsStage.isShowing()) {
            return;
        }

        final long version = recommendationVersion.incrementAndGet();
        final RecommendationSnapshot snapshot = new RecommendationSnapshot(
                sleepSlider.getValue(), waterSlider.getValue(), exerciseSlider.getValue(),
                stressSlider.getValue(), moodChoiceBox.getValue(),
                healthData.getWaterGoalGlasses(), healthData.getExerciseGoalMinutes());

        recommendationExecutor.submit(() -> {
            RecommendationResult result = RecommendationEngine.generate(snapshot);
            Platform.runLater(() -> {
                if (version != recommendationVersion.get() || recommendationsContent == null) return;
                renderRecommendations(result);
            });
        });
    }

    private void renderRecommendations(RecommendationResult result) {
        // Keep the heading, intro, and status label; replace the previous card grid.
        if (recommendationsContent.getChildren().size() > 3) {
            recommendationsContent.getChildren().remove(3, recommendationsContent.getChildren().size());
        }
        recommendationStatusLabel.setText("Updated in background • " + result.summary);

        VBox dashboard = new VBox(18);
        dashboard.getStyleClass().add("smart-recommendations-dashboard");

        HBox rings = new HBox(16);
        rings.setAlignment(javafx.geometry.Pos.CENTER);
        rings.getStyleClass().add("recommendation-ring-row");
        rings.getChildren().addAll(
                createRingCard("Sleep", result.sleepProgress, result.sleepText, "#a78bfa"),
                createRingCard("Water", result.waterProgress, result.waterText, "#38bdf8"),
                createRingCard("Exercise", result.exerciseProgress, result.exerciseText, "#4ade80"),
                createRingCard("Overall", result.overallProgress, result.overallText, "#60a5fa")
        );

        VBox nutrition = new VBox(12);
        nutrition.getStyleClass().add("recommendation-card");
        Label nutritionTitle = new Label("Nutrition targets");
        nutritionTitle.getStyleClass().add("recommendation-section-title");
        Label nutritionSubtitle = new Label("Fill the bars as you log your daily nutrition.");
        nutritionSubtitle.getStyleClass().add("recommendations-intro");
        nutrition.getChildren().addAll(nutritionTitle, nutritionSubtitle);
        nutrition.getChildren().add(createNutritionRow("Protein", result.proteinCurrent, result.proteinTarget, "#60a5fa"));
        nutrition.getChildren().add(createNutritionRow("Calories", result.caloriesCurrent, result.caloriesTarget, "#4ade80"));
        nutrition.getChildren().add(createNutritionRow("Water", result.waterCurrent, result.waterTarget, "#38bdf8"));

        GridPane actionGrid = new GridPane();
        actionGrid.setHgap(12);
        actionGrid.setVgap(12);
        for (int i = 0; i < result.cards.size(); i++) {
            RecommendationCardData data = result.cards.get(i);
            VBox card = new VBox(7);
            card.getStyleClass().addAll("recommendation-card", data.attention ? "recommendation-card-attention" : "recommendation-card-positive");
            Label title = new Label(data.title);
            title.getStyleClass().add("recommendation-title");
            Label message = new Label(data.message);
            message.setWrapText(true);
            message.getStyleClass().add(data.attention ? "recommendation-attention" : "recommendation-positive");
            card.getChildren().addAll(title, message);
            actionGrid.add(card, i % 2, i / 2);
            GridPane.setHgrow(card, Priority.ALWAYS);
        }

        dashboard.getChildren().addAll(rings, nutrition, actionGrid);
        recommendationsContent.getChildren().add(dashboard);
    }

    private VBox createRingCard(String title, double progress, String centerText, String color) {
        VBox box = new VBox(6);
        box.setAlignment(javafx.geometry.Pos.CENTER);
        box.getStyleClass().add("recommendation-ring-card");

        // Use a fixed Pane rather than StackPane for the ring layers.
        // StackPane re-centers an Arc according to its changing layout bounds,
        // so a different sweep angle can make the coloured arc appear to jump.
        // With explicit center coordinates, the background circle, arc and text
        // stay locked together even when the value is updated by a worker thread.
        final double size = 132;
        final double centerX = size / 2.0;
        final double centerY = size / 2.0;
        final double radius = 48;

        Pane ringPane = new Pane();
        ringPane.setPrefSize(size, size);
        ringPane.setMinSize(size, size);
        ringPane.setMaxSize(size, size);

        Circle track = new Circle(centerX, centerY, radius);
        track.setFill(Color.TRANSPARENT);
        track.setStroke(Color.web("#30344b"));
        track.setStrokeWidth(10);

        double safeProgress = Math.max(0, Math.min(1, progress));
        Arc fill = new Arc(centerX, centerY, radius, radius, 90, -360 * safeProgress);
        fill.setType(ArcType.OPEN);
        fill.setFill(Color.TRANSPARENT);
        fill.setStroke(Color.web(color));
        fill.setStrokeWidth(10);
        fill.setStrokeLineCap(StrokeLineCap.ROUND);

        Label center = new Label(centerText);
        center.getStyleClass().add("recommendation-ring-value");
        center.setLayoutX(centerX - 48);
        center.setLayoutY(centerY - 15);
        center.setPrefWidth(96);
        center.setPrefHeight(30);
        center.setAlignment(javafx.geometry.Pos.CENTER);

        ringPane.getChildren().addAll(track, fill, center);

        Label name = new Label(title);
        name.getStyleClass().add("recommendation-ring-title");
        box.getChildren().addAll(ringPane, name);
        return box;
    }

    private VBox createNutritionRow(String labelText, double current, double target, String color) {
        VBox row = new VBox(4);
        HBox header = new HBox(8);
        header.setAlignment(javafx.geometry.Pos.CENTER_LEFT);
        Label name = new Label(labelText);
        name.getStyleClass().add("nutrition-row-label");
        Label value = new Label(String.format(Locale.US, "%.0f / %.0f", current, target));
        value.getStyleClass().add("nutrition-row-value");
        javafx.scene.layout.Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        header.getChildren().addAll(name, spacer, value);

        ProgressBar bar = new ProgressBar(target <= 0 ? 0 : Math.max(0, Math.min(1, current / target)));
        bar.setMaxWidth(Double.MAX_VALUE);
        bar.getStyleClass().add("recommendation-progress-bar");
        bar.setStyle("-fx-accent: " + color + ";");
        row.getChildren().addAll(header, bar);
        return row;
    }

    private void applyStylesToScene(Scene scene) {
        String css = getClass().getResource(darkMode ? "styles-dark.css" : "styles.css").toExternalForm();
        scene.getStylesheets().add(css);
    }

    private static final class RecommendationSnapshot {
        final double sleep, water, exercise, stress, waterGoal, exerciseGoal;
        final String mood;
        RecommendationSnapshot(double sleep, double water, double exercise, double stress,
                                String mood, double waterGoal, double exerciseGoal) {
            this.sleep = sleep; this.water = water; this.exercise = exercise; this.stress = stress;
            this.mood = mood == null ? "Okay" : mood; this.waterGoal = waterGoal; this.exerciseGoal = exerciseGoal;
        }
    }

    private static final class RecommendationCardData {
        final String title, message; final boolean attention;
        RecommendationCardData(String title, String message, boolean attention) {
            this.title = title; this.message = message; this.attention = attention;
        }
    }

    private static final class RecommendationResult {
        final List<RecommendationCardData> cards; final String summary;
        final double sleepProgress, waterProgress, exerciseProgress, overallProgress;
        final String sleepText, waterText, exerciseText, overallText;
        final double proteinCurrent, proteinTarget, caloriesCurrent, caloriesTarget, waterCurrent, waterTarget;

        RecommendationResult(List<RecommendationCardData> cards, String summary,
                             double sleepProgress, double waterProgress, double exerciseProgress, double overallProgress,
                             String sleepText, String waterText, String exerciseText, String overallText,
                             double proteinCurrent, double proteinTarget, double caloriesCurrent, double caloriesTarget,
                             double waterCurrent, double waterTarget) {
            this.cards = cards; this.summary = summary;
            this.sleepProgress = sleepProgress; this.waterProgress = waterProgress;
            this.exerciseProgress = exerciseProgress; this.overallProgress = overallProgress;
            this.sleepText = sleepText; this.waterText = waterText; this.exerciseText = exerciseText; this.overallText = overallText;
            this.proteinCurrent = proteinCurrent; this.proteinTarget = proteinTarget;
            this.caloriesCurrent = caloriesCurrent; this.caloriesTarget = caloriesTarget;
            this.waterCurrent = waterCurrent; this.waterTarget = waterTarget;
        }
    }

    /** Pure worker-side logic: no JavaFX controls are accessed here. */
    private static final class RecommendationEngine {
        static RecommendationResult generate(RecommendationSnapshot s) {
            List<RecommendationCardData> cards = new ArrayList<>();
            boolean sleepAttention = s.sleep < 7;
            cards.add(new RecommendationCardData("💤 Sleep",
                    sleepAttention ? "Aim for a consistent 7–9 hour sleep window and reduce screen time before bed."
                            : "Your sleep duration is in a reasonable range. Keep your sleep schedule consistent.", sleepAttention));

            boolean waterAttention = s.water < s.waterGoal;
            cards.add(new RecommendationCardData("💧 Hydration",
                    waterAttention ? String.format(Locale.US, "You are %.0f glasses below your configured goal. Spread water intake across the day.", Math.max(0, s.waterGoal - s.water))
                            : "You are meeting your configured water goal. Continue drinking regularly.", waterAttention));

            boolean exerciseAttention = s.exercise < s.exerciseGoal;
            cards.add(new RecommendationCardData("🏃 Exercise",
                    exerciseAttention ? String.format(Locale.US, "Add about %.0f minutes of manageable movement, such as walking or stretching.", Math.max(0, s.exerciseGoal - s.exercise))
                            : "You are meeting your exercise goal. Keep activity sustainable and include recovery.", exerciseAttention));

            boolean stressAttention = s.stress >= 7;
            cards.add(new RecommendationCardData("🧠 Stress",
                    stressAttention ? "Your reported stress is high. Try paced breathing, a short break, or reaching out to someone you trust."
                            : "Your reported stress is not in the high range. Continue using healthy coping habits.", stressAttention));

            boolean moodAttention = "Low".equalsIgnoreCase(s.mood) || "Stressed".equalsIgnoreCase(s.mood);
            cards.add(new RecommendationCardData("🙂 Mood",
                    moodAttention ? "Consider rest, a calming activity, or talking with someone supportive."
                            : "Keep activities that support your wellbeing and monitor changes in mood.", moodAttention));

            int estimatedCalories = (int) Math.round(1900 + (s.exercise * 8) - (s.stress * 10));
            estimatedCalories = Math.max(1600, Math.min(2800, estimatedCalories));
            int estimatedProtein = (int) Math.round(75 + (s.exercise * 0.35));
            cards.add(new RecommendationCardData("🍽 Nutrition targets",
                    String.format(Locale.US, "Estimated starting point: around %,d kcal/day and %d g protein/day. Adjust with your personal needs and a qualified professional.", estimatedCalories, estimatedProtein), false));

            int attentionCount = 0;
            for (RecommendationCardData c : cards) if (c.attention) attentionCount++;

            double sleepProgress = Math.min(1.0, s.sleep / 8.0);
            double waterProgress = s.waterGoal <= 0 ? 0 : Math.min(1.0, s.water / s.waterGoal);
            double exerciseProgress = s.exerciseGoal <= 0 ? 0 : Math.min(1.0, s.exercise / s.exerciseGoal);
            double overallProgress = (sleepProgress + waterProgress + exerciseProgress + (1.0 - Math.min(1.0, s.stress / 10.0))) / 4.0;
            double proteinTarget = Math.max(75, Math.round(75 + (s.exercise * 0.35)));
            return new RecommendationResult(cards,
                    attentionCount == 0 ? "All tracked areas are currently on target" : attentionCount + " area(s) need attention",
                    sleepProgress, waterProgress, exerciseProgress, overallProgress,
                    String.format(Locale.US, "%.1fh / 8h", s.sleep),
                    String.format(Locale.US, "%.0f / %.0f", s.water, s.waterGoal),
                    String.format(Locale.US, "%.0f / %.0f min", s.exercise, s.exerciseGoal),
                    String.format(Locale.US, "%.0f%%", overallProgress * 100),
                    0, proteinTarget, 0, estimatedCalories, s.water, s.waterGoal);
        }
    }

    // ===================== JSON / API (WEEK 7) =====================

    /**
     * Demonstrates JSON serialization: Java HealthData object -> JSON text.
     * The JSON is shown to the user so the structure can be inspected.
     */
    @FXML
    private void handleOnlineApiDemo() {
        jsonButton.setDisable(true);
        jsonButton.setText("Testing API...");
        recommendationExecutor.submit(() -> {
            try {
                JsonHealthService.OnlineApiDemoResult result = JsonHealthService.runOnlineApiDemo();
                Platform.runLater(() -> {
                    TextArea area = new TextArea();
                    area.setEditable(false);
                    area.setWrapText(true);
                    area.setText("LIVE HTTP GET SUCCESS\n\n" +
                            "Endpoint: " + result.url() + "\n\n" +
                            "Jackson-parsed fields:\n" +
                            "id = " + result.id() + "\n" +
                            "title = " + result.title() + "\n" +
                            "category = " + result.category() + "\n" +
                            "price = " + result.price() + "\n\n" +
                            "Raw JSON response:\n" + result.rawJson());
                    area.setPrefRowCount(20); area.setPrefColumnCount(70);
                    Dialog<ButtonType> dialog = new Dialog<>();
                    dialog.setTitle("Live Online JSON API Demonstration");
                    dialog.setHeaderText("HTTP GET → JSON response → Jackson JsonNode parsing");
                    dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
                    dialog.getDialogPane().setContent(area);
                    dialog.showAndWait();
                    jsonButton.setDisable(false); jsonButton.setText("🌐 JSON API");
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    jsonButton.setDisable(false); jsonButton.setText("🌐 JSON API");
                    showJsonError("Online API test failed", e);
                });
            }
        });
    }

    @FXML
    private void handleOpenJson() {
        try {
            String json = JsonHealthService.toJson(healthData);

            TextArea area = new TextArea(json);
            area.setEditable(false);
            area.setWrapText(false);
            area.setPrefRowCount(18);
            area.setPrefColumnCount(60);

            Dialog<ButtonType> dialog = new Dialog<>();
            dialog.setTitle("HealthLens - JSON Data");
            dialog.setHeaderText("Current HealthData converted to JSON");
            dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
            dialog.getDialogPane().setContent(area);
            dialog.showAndWait();
        } catch (Exception e) {
            showJsonError("Could not create JSON", e);
        }
    }

    /**
     * Demonstrates JSON deserialization: JSON text -> Java HealthData object.
     * It also shows that parsed values can flow through the existing
     * View -> Model -> View pipeline without rewriting the dashboard.
     */
    @FXML
    private void handleImportJson() {
        TextInputDialog input = new TextInputDialog();
        input.setTitle("Import Health JSON");
        input.setHeaderText("Paste a HealthLens JSON object");
        input.setContentText("JSON:");

        input.showAndWait().ifPresent(json -> {
            try {
                HealthData imported = JsonHealthService.fromJson(json);

                healthData.setSleepHours(imported.getSleepHours());
                healthData.setWaterGlasses(imported.getWaterGlasses());
                healthData.setExerciseMinutes(imported.getExerciseMinutes());
                healthData.setStressLevel(imported.getStressLevel());
                if (imported.getMood() != null) {
                    healthData.setMood(imported.getMood());
                }

                sleepSlider.setValue(clamp(healthData.getSleepHours(),
                        sleepSlider.getMin(), sleepSlider.getMax()));
                waterSlider.setValue(clamp(healthData.getWaterGlasses(),
                        waterSlider.getMin(), waterSlider.getMax()));
                exerciseSlider.setValue(clamp(healthData.getExerciseMinutes(),
                        exerciseSlider.getMin(), exerciseSlider.getMax()));
                stressSlider.setValue(clamp(healthData.getStressLevel(),
                        stressSlider.getMin(), stressSlider.getMax()));
                moodChoiceBox.setValue(healthData.getMood());

                handleUpdate();
            } catch (Exception e) {
                showJsonError("Invalid JSON", e);
            }
        });
    }

    /**
     * Demonstrates API URL response handling.
     *
     * The HTTP request and JSON parsing happen on a background thread.
     * Platform.runLater() is used only for updating JavaFX controls.
     */
    @FXML
    private void handleFetchJsonApi() {
        ButtonType sampleButton = new ButtonType("Use Sample JSON");
        ButtonType apiButton = new ButtonType("Fetch API URL");
        ButtonType cancelButton = ButtonType.CANCEL;

        Alert choice = new Alert(Alert.AlertType.CONFIRMATION);
        choice.setTitle("Health API / JSON");
        choice.setHeaderText("Choose where to get the HealthLens JSON data");
        choice.setContentText("You can use the bundled sample JSON file or fetch JSON from a real API URL.");
        choice.getButtonTypes().setAll(sampleButton, apiButton, cancelButton);

        choice.showAndWait().ifPresent(selected -> {
            if (selected == sampleButton) {
                fetchBundledSampleJson();
            } else if (selected == apiButton) {
                fetchJsonFromApiUrl();
            }
        });
    }

    /** Loads the sample JSON bundled inside src/main/resources. */
    private void fetchBundledSampleJson() {
        jsonButton.setDisable(true);
        jsonButton.setText("Loading JSON...");

        recommendationExecutor.submit(() -> {
            try {
                String response = JsonHealthService.loadSampleApiResponse();
                HealthData imported = JsonHealthService.parseApiResponse(response);

                Platform.runLater(() -> {
                    applyJsonHealthData(imported);
                    jsonButton.setDisable(false);
                    jsonButton.setText("JSON / API");
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    jsonButton.setDisable(false);
                    jsonButton.setText("JSON / API");
                    showJsonError("Sample JSON error", e);
                });
            }
        });
    }

    /**
     * Fetches a real JSON API URL. If the response matches the HealthLens
     * HealthData schema, it is imported into the dashboard. Otherwise the
     * response is displayed as generic JSON instead of being forced into
     * HealthData (which would cause an "Unrecognized field" error).
     */
    private void fetchJsonFromApiUrl() {
        TextInputDialog input = new TextInputDialog(JsonHealthService.ONLINE_DEMO_URL);
        input.setTitle("Health API / JSON");
        input.setHeaderText("Fetch JSON from a real API URL");
        input.setContentText("API URL:");

        input.showAndWait().ifPresent(url -> {
            jsonButton.setDisable(true);
            jsonButton.setText("Fetching JSON...");

            recommendationExecutor.submit(() -> {
                try {
                    String response = JsonHealthService.fetchApiResponse(url);
                    JsonHealthService.ApiResponseResult result =
                            JsonHealthService.inspectApiResponse(url, response);

                    Platform.runLater(() -> {
                        if (result.isHealthData()) {
                            applyJsonHealthData(result.healthData());
                        } else {
                            showGenericApiResponse(result);
                        }
                        jsonButton.setDisable(false);
                        jsonButton.setText("JSON / API");
                    });
                } catch (Exception e) {
                    Platform.runLater(() -> {
                        jsonButton.setDisable(false);
                        jsonButton.setText("JSON / API");
                        showJsonError("API / JSON error", e);
                    });
                }
            });
        });
    }

    /** Shows a valid JSON response that does not use the HealthLens schema. */
    private void showGenericApiResponse(JsonHealthService.ApiResponseResult result) {
        TextArea area = new TextArea();
        area.setEditable(false);
        area.setWrapText(true);
        area.setText("LIVE HTTP GET SUCCESS\n\n" +
                "Endpoint: " + result.url() + "\n\n" +
                "This API returned valid JSON, but its fields are not the HealthLens HealthData schema.\n" +
                "The response was therefore parsed safely with Jackson JsonNode instead of being forced into HealthData.\n\n" +
                "Detected fields:\n" + result.summary() + "\n\n" +
                "Raw JSON response:\n" + result.rawJson());
        area.setPrefRowCount(20);
        area.setPrefColumnCount(70);

        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Live JSON API Response");
        dialog.setHeaderText("HTTP GET → JSON → Jackson JsonNode");
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
        dialog.getDialogPane().setContent(area);
        dialog.showAndWait();
    }

    /** Applies a JSON/API HealthData object to the existing dashboard. */
    private void applyJsonHealthData(HealthData imported) {
        healthData.setSleepHours(imported.getSleepHours());
        healthData.setWaterGlasses(imported.getWaterGlasses());
        healthData.setExerciseMinutes(imported.getExerciseMinutes());
        healthData.setStressLevel(imported.getStressLevel());
        if (imported.getMood() != null) {
            healthData.setMood(imported.getMood());
        }

        sleepSlider.setValue(clamp(imported.getSleepHours(),
                sleepSlider.getMin(), sleepSlider.getMax()));
        waterSlider.setValue(clamp(imported.getWaterGlasses(),
                waterSlider.getMin(), waterSlider.getMax()));
        exerciseSlider.setValue(clamp(imported.getExerciseMinutes(),
                exerciseSlider.getMin(), exerciseSlider.getMax()));
        stressSlider.setValue(clamp(imported.getStressLevel(),
                stressSlider.getMin(), stressSlider.getMax()));
        moodChoiceBox.setValue(imported.getMood());

        handleUpdate();
    }

    private void showJsonError(String title, Exception e) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(e.getMessage() == null ? e.toString() : e.getMessage());
        alert.showAndWait();
    }

    @FXML
    private void handleReset() {
        healthData.resetEntriesToDefaults();
        sleepSlider.setValue(healthData.getSleepHours());
        waterSlider.setValue(healthData.getWaterGlasses());
        exerciseSlider.setValue(healthData.getExerciseMinutes());
        stressSlider.setValue(healthData.getStressLevel());
        moodChoiceBox.setValue(healthData.getMood());
        handleUpdate();
    }

    /** Smoothly animates a progress bar to its new value instead of jumping instantly. */
    private void animateBar(ProgressBar bar, double target) {
        bar.getStyleClass().removeAll("progress-good", "progress-medium", "progress-poor", "progress-neutral");
        if (target >= 0.8) {
            bar.getStyleClass().add("progress-good");
        } else if (target >= 0.5) {
            bar.getStyleClass().add("progress-medium");
        } else {
            bar.getStyleClass().add("progress-poor");
        }

        Timeline timeline = new Timeline(
                new KeyFrame(Duration.millis(450),
                        new KeyValue(bar.progressProperty(), target, Interpolator.EASE_BOTH))
        );
        timeline.play();
    }

    /** Creates the five visual segments used by the mobile-style battery indicator. */
    private void setupBatteryIndicator() {
        batterySegments.getChildren().clear();
        batterySegmentNodes.clear();

        for (int i = 0; i < 10; i++) {
            Region segment = new Region();
            segment.getStyleClass().add("battery-segment");
            segment.setPrefSize(9, 30);
            segment.setMinSize(9, 30);
            segment.setMaxSize(9, 30);
            batterySegmentNodes.add(segment);
        }

        // Add segments from left to right like a mobile battery indicator.
        batterySegments.getChildren().addAll(batterySegmentNodes);
        batteryPercentLabel.setTooltip(new Tooltip("Battery percentage is calculated from your overall health score."));
    }

    /** Updates the battery using the existing overall health score. */
    private void updateBatteryIndicator(ScoreResult result) {
        int percent = result.getOverallPercent();
        int filledSegments = (int) Math.ceil(percent / 10.0);
        String batteryTier = "battery-" + result.getTier();

        batteryPercentLabel.setText(percent + "%");
        ScaleTransition pulse = new ScaleTransition(Duration.millis(220), batteryPercentLabel);
        pulse.setFromX(0.92);
        pulse.setFromY(0.92);
        pulse.setToX(1.0);
        pulse.setToY(1.0);
        pulse.play();
        batteryPercentLabel.getStyleClass().removeAll("battery-good", "battery-medium", "battery-poor");
        batteryPercentLabel.getStyleClass().add(batteryTier);

        for (int i = 0; i < batterySegmentNodes.size(); i++) {
            Region segment = batterySegmentNodes.get(i);
            segment.getStyleClass().removeAll("battery-filled", "battery-empty", "battery-good", "battery-medium", "battery-poor");
            boolean shouldFill = i < filledSegments;
            if (shouldFill) {
                segment.getStyleClass().addAll("battery-filled", batteryTier);
            } else {
                segment.getStyleClass().add("battery-empty");
            }

            // Smoothly animate each segment whenever the score changes.
            segment.setOpacity(0.35);
            Timeline fillAnimation = new Timeline(
                    new KeyFrame(Duration.ZERO, new KeyValue(segment.opacityProperty(), 0.35)),
                    new KeyFrame(Duration.millis(180 + (i * 70)),
                            new KeyValue(segment.opacityProperty(), shouldFill ? 1.0 : 0.55, Interpolator.EASE_BOTH))
            );
            fillAnimation.play();
        }
    }

    /** Pure UI work: takes a ScoreResult from the Model and displays it. No scoring logic here. */
    private void renderSummary(ScoreResult result) {
        updateBatteryIndicator(result);
        overallScoreLabel.setText("Overall Score: " + result.getOverallPercent() + "%");

        overallScoreLabel.getStyleClass().removeAll("score-good", "score-medium", "score-poor");
        summaryLabel.getStyleClass().removeAll("summary-good", "summary-medium", "summary-poor");

        overallScoreLabel.getStyleClass().add("score-" + result.getTier());
        summaryLabel.getStyleClass().add("summary-" + result.getTier());

        summaryLabel.setText(result.getSummaryText());
    }

    // ===================== PREFERENCES (SAVE / LOAD) =====================

    /**
     * Restores goals, last-entered habit values, mood, and theme choice from
     * the previous session straight into the Model. Uses java.util.prefs,
     * which stores small values per-OS-user automatically — no file to manage.
     */
    private void loadPreferences() {
        healthData.setSleepGoalHours(prefs.getDouble("goal.sleep", HealthData.DEFAULT_SLEEP_GOAL_HOURS));
        healthData.setWaterGoalGlasses(prefs.getDouble("goal.water", HealthData.DEFAULT_WATER_GOAL_GLASSES));
        healthData.setExerciseGoalMinutes(prefs.getDouble("goal.exercise", HealthData.DEFAULT_EXERCISE_GOAL_MINUTES));
        healthData.setStressComfortMax(prefs.getDouble("goal.stressMax", HealthData.DEFAULT_STRESS_COMFORT_MAX));
        darkMode = prefs.getBoolean("darkMode", false);

        healthData.setSleepHours(prefs.getDouble("last.sleep", HealthData.DEFAULT_SLEEP_HOURS));
        healthData.setWaterGlasses(prefs.getDouble("last.water", HealthData.DEFAULT_WATER_GLASSES));
        healthData.setExerciseMinutes(prefs.getDouble("last.exercise", HealthData.DEFAULT_EXERCISE_MINUTES));
        healthData.setStressLevel(prefs.getDouble("last.stress", HealthData.DEFAULT_STRESS_LEVEL));
        healthData.setMood(prefs.get("last.mood", HealthData.DEFAULT_MOOD));

        sleepSlider.setValue(healthData.getSleepHours());
        waterSlider.setValue(healthData.getWaterGlasses());
        exerciseSlider.setValue(healthData.getExerciseMinutes());
        stressSlider.setValue(healthData.getStressLevel());

        // Live value labels won't have fired their listeners yet at this point
        // (they're attached in setupLiveValueLabels(), called right after this),
        // so set the initial label text manually here.
        sleepValueLabel.setText(String.format(Locale.US, "%.1f h", sleepSlider.getValue()));
        waterValueLabel.setText(String.format(Locale.US, "%d", Math.round(waterSlider.getValue())));
        exerciseValueLabel.setText(String.format(Locale.US, "%d min", Math.round(exerciseSlider.getValue())));
        stressValueLabel.setText(String.format(Locale.US, "%d", Math.round(stressSlider.getValue())));
    }

    private void savePreferences() {
        prefs.putDouble("goal.sleep", healthData.getSleepGoalHours());
        prefs.putDouble("goal.water", healthData.getWaterGoalGlasses());
        prefs.putDouble("goal.exercise", healthData.getExerciseGoalMinutes());
        prefs.putDouble("goal.stressMax", healthData.getStressComfortMax());

        prefs.putDouble("last.sleep", healthData.getSleepHours());
        prefs.putDouble("last.water", healthData.getWaterGlasses());
        prefs.putDouble("last.exercise", healthData.getExerciseMinutes());
        prefs.putDouble("last.stress", healthData.getStressLevel());

        if (healthData.getMood() != null) {
            prefs.put("last.mood", healthData.getMood());
        }
    }
}
